项目命令如下
# 安装所有依赖

```bash
npm i
```

# 启动 mock 接口服务

```bash
npm run serve
```

# 启动项目

```bash
npm run start

```
