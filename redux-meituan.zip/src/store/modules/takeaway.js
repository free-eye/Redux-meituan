//编写store

import {createSlice} from '@reduxjs/toolkit'
import axios from "axios"
import foodItem from "../../components/FoodsCategory/FoodItem";

const foodsStore = createSlice({
    name: 'foods',
    initialState: {
        //商品列表
        foodsList: [],
        //菜单激活下标值
        activeIndex: 0,
        //购物车列表
        cartList: []
    },
    reducers: {
        //更改商品列表
        setFoodsList(state, action) {
            state.foodsList = action.payload
        },
        //更改activeIndex
        changeActiveIndex(state, action) {
            state.activeIndex = action.payload
        },
        //添加购物车
        addCartList(state, action) {
            //是否添加过?通过action.payload.id匹配cartlist中的id
            const item = state.cartList.find(item => item.id === action.payload.id)
            if (item) {
                item.count++
            } else {
                state.cartList.push(action.payload)
            }
        },
        //count增加
        increCount(state, action) {
            //找到当前选择的对象
            const item = state.cartList.find(item => item.id === action.payload.id)
            item.count++
        },
        //count减少
        decreCount(state,action) {
            //找到当前选择的对象
            const item = state.cartList.find(item => item.id === action.payload.id)
            if (item.count > 0) {
                item.count--
                if (item.count === 0) {
                    state.cartList = state.cartList.filter(item => item.id !== action.payload.id);
                }
            }
        },
        //清除购物车
        clearCart(state){
            state.cartList = []
        }
    }
})

//异步获取部分
const {setFoodsList, changeActiveIndex, addCartList,increCount,decreCount,clearCart} = foodsStore.actions
const fetchFoodsList = () => {
    return async (dispatch) => {
        //编写异步逻辑
        const res = await axios.get('http://localhost:3004/takeaway')
        //调用dispatch函数提交action
        dispatch(setFoodsList(res.data))
    }
}

export {fetchFoodsList, changeActiveIndex, addCartList,increCount,decreCount,clearCart}

const reducer = foodsStore.reducer

export default reducer